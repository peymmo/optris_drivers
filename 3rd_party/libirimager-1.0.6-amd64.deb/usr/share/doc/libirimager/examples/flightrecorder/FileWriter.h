#ifndef LINUX_EXAMPLES_FLIGHTRECORDER_FILEWRITER_H_
#define LINUX_EXAMPLES_FLIGHTRECORDER_FILEWRITER_H_

#include <fstream>
#include "IRImager.h"

namespace optris
{

class FileWriter
{
public:

  FileWriter(char* basedir, optris::IRImager* imager);

  virtual ~FileWriter();

  void write(unsigned int id, unsigned char* img, unsigned int size);

private:

  std::ofstream _f;

};

} // namespace

#endif
