#include "FileWriter.h"
#include <iostream>

namespace optris
{

FileWriter::FileWriter(char* basedir, optris::IRImager* imager)
{
  time_t timeStart;
  timeStart = time(NULL);

  unsigned long serial = imager->getSerial();

  char filename[128];
  struct tm *timeLocal = localtime(&timeStart);
  char sdate[64];
  char stime[64];
  sprintf(sdate, "%04d%02d%02d", timeLocal->tm_year+1900, timeLocal->tm_mon+1, timeLocal->tm_mday);
  sprintf(stime, "%02d%02d%02d", timeLocal->tm_hour, timeLocal->tm_min, timeLocal->tm_sec);
  sprintf(filename, "%s/ir_%ld_%s_%s.raw", basedir, serial, sdate, stime);
  _f.open(filename, std::ios::out | std::ios::binary);
  _f.write((const char*)sdate, 8);
  _f.write((const char*)stime, 6);
  _f.write((const char*)&serial, sizeof(serial));
  // write FrameConfig
  int width  = imager->getWidthIn();
  int height = imager->getHeightIn();
  unsigned short bitCount = imager->getBitCount();
  long long avgTimePerFrame = imager->getAvgTimePerFrame();
  _f.write((const char*)&width, sizeof(width));
  _f.write((const char*)&height, sizeof(height));
  _f.write((const char*)&bitCount, sizeof(bitCount));
  _f.write((const char*)&avgTimePerFrame, sizeof(avgTimePerFrame));
}

FileWriter::~FileWriter()
{
  if(_f.is_open()) _f.close();
}

void FileWriter::write(unsigned int id, unsigned char* img, unsigned int size)
{
  _f.write((const char*)&id, sizeof(id));
  _f.write((const char*)img, size*sizeof(*img));
}

}
