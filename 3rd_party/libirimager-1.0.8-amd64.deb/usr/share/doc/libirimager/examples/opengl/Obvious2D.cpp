#include "Obvious2D.h"

#include <iostream>
#include <stdio.h>
#include <string.h>
#define GL_GLEXT_PROTOTYPES 1
#include <GL/freeglut.h>
#include <signal.h>
#include <unistd.h>

using namespace std;

namespace obvious
{

Obvious2D* g_this[16];

bool g_is_glut_initialized = false;
bool g_instance_map[16] = {0};

typedef void (*fpOnCloseEvent)(void);
typedef void (*fpOnToggleScreen)(void);
typedef void (*fpOnKeyboard)(unsigned char key, int x, int y);
typedef void (*fpOnChangeSize)(GLsizei w, GLsizei h);
typedef void (*fpSetupGlut)(void);

template <unsigned int instance>
void onCloseEvent();
static fpOnCloseEvent _onCloseEventSlot[] =
{
    &onCloseEvent<0>,
    &onCloseEvent<1>,
    &onCloseEvent<2>,
    &onCloseEvent<3>,
    &onCloseEvent<4>,
    &onCloseEvent<5>,
    &onCloseEvent<6>,
    &onCloseEvent<7>,
    &onCloseEvent<8>,
    &onCloseEvent<9>,
    &onCloseEvent<10>,
    &onCloseEvent<11>,
    &onCloseEvent<12>,
    &onCloseEvent<13>,
    &onCloseEvent<14>,
    &onCloseEvent<15>
};

template <unsigned int instance>
void onToggleScreen();
static fpOnToggleScreen _onToggleScreenSlot[] =
{
    &onToggleScreen<0>,
    &onToggleScreen<1>,
    &onToggleScreen<2>,
    &onToggleScreen<3>,
    &onToggleScreen<4>,
    &onToggleScreen<5>,
    &onToggleScreen<6>,
    &onToggleScreen<7>,
    &onToggleScreen<8>,
    &onToggleScreen<9>,
    &onToggleScreen<10>,
    &onToggleScreen<11>,
    &onToggleScreen<12>,
    &onToggleScreen<13>,
    &onToggleScreen<14>,
    &onToggleScreen<15>
};

template <unsigned int instance>
void onKeyboard(unsigned char key, int x, int y);
static fpOnKeyboard _onKeyboardSlot[] =
{
    &onKeyboard<0>,
    &onKeyboard<1>,
    &onKeyboard<2>,
    &onKeyboard<3>,
    &onKeyboard<4>,
    &onKeyboard<5>,
    &onKeyboard<6>,
    &onKeyboard<7>,
    &onKeyboard<8>,
    &onKeyboard<9>,
    &onKeyboard<10>,
    &onKeyboard<11>,
    &onKeyboard<12>,
    &onKeyboard<13>,
    &onKeyboard<14>,
    &onKeyboard<15>
};

template <unsigned int instance>
void onChangeSize(GLsizei w, GLsizei h);
static fpOnChangeSize _onChangeSizeSlot[] =
{
    &onChangeSize<0>,
    &onChangeSize<1>,
    &onChangeSize<2>,
    &onChangeSize<3>,
    &onChangeSize<4>,
    &onChangeSize<5>,
    &onChangeSize<6>,
    &onChangeSize<7>,
    &onChangeSize<8>,
    &onChangeSize<9>,
    &onChangeSize<10>,
    &onChangeSize<11>,
    &onChangeSize<12>,
    &onChangeSize<13>,
    &onChangeSize<14>,
    &onChangeSize<15>
};

template <unsigned int instance>
void setupGlut();
static fpSetupGlut _setupGlutSlot[] =
{
    &setupGlut<0>,
    &setupGlut<1>,
    &setupGlut<2>,
    &setupGlut<3>,
    &setupGlut<4>,
    &setupGlut<5>,
    &setupGlut<6>,
    &setupGlut<7>,
    &setupGlut<8>,
    &setupGlut<9>,
    &setupGlut<10>,
    &setupGlut<11>,
    &setupGlut<12>,
    &setupGlut<13>,
    &setupGlut<14>,
    &setupGlut<15>
};

int getFreeSlot()
{
  int id = -1;
  for(int i=0; i<16; i++)
  {
    if(g_instance_map[i]==false)
    {
      id = i;
      break;
    }
  }
  return id;
}

template <unsigned int instance>
void onCloseEvent()
{
  Obvious2D* viewer = g_this[instance];
  viewer->terminate();
  if(glutGameModeGet(GLUT_GAME_MODE_ACTIVE)) glutLeaveGameMode();
}

template <unsigned int instance>
void onToggleScreen()
{
  Obvious2D* viewer = g_this[instance];
  if(!viewer->getFullscreen())
  {
    viewer->setWidth(viewer->getScreenWidth());
    viewer->setHeight(viewer->getScreenHeight());
    glutReshapeWindow(viewer->getWidth(), viewer->getHeight());
    glutFullScreen();
    _setupGlutSlot[instance]();
    viewer->setFullscreen(true);
  }
  else
  {
    viewer->setWidth(viewer->getInitWidth());
    viewer->setHeight(viewer->getInitHeight());
    glutReshapeWindow(viewer->getWidth(), viewer->getHeight());
    _setupGlutSlot[instance]();
    viewer->setFullscreen(false);
  }
}

// Custom keyboard handler for registered callback functions
template <unsigned int instance>
void onKeyboard(unsigned char key, int x, int y)
{
  Obvious2D* viewer = g_this[instance];
  viewer->processCallback(key);
}

// Resize handler
template <unsigned int instance>
void onChangeSize(GLsizei w, GLsizei h)
{
  Obvious2D* viewer = g_this[instance];
  viewer->setWidth(w);
  viewer->setHeight(h);
  glViewport(0, 0, w, h);
  _setupGlutSlot[instance]();
  glutPostRedisplay();
}

template <unsigned int instance>
void setupGlut()
{
  glDisable(GL_ALPHA_TEST);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_BLEND);
  glDisable(GL_DITHER);
  glDisable(GL_FOG);
  glDisable(GL_LIGHTING);
  glDisable(GL_LOGIC_OP);
  glDisable(GL_STENCIL_TEST);
  glDisable(GL_TEXTURE_1D);

  glRasterPos2f(-1.0, 1.0);

  glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_CONTINUE_EXECUTION);
  //glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_EXIT);

  glutCloseFunc (_onCloseEventSlot[instance]);
  glutKeyboardFunc(_onKeyboardSlot[instance]);
  glutReshapeFunc(_onChangeSizeSlot[instance]);
}

Obvious2D::Obvious2D(unsigned int width, unsigned int height, const char* title)
{
  char fake[]      = "dummy";
  char *fakeargv[] = { fake, NULL };
  int argc         = 1;

  if(width==0 || height==0)
  {
    cout << "Obvious2D:: Wrong with and height passed" << endl;
    abort();
  }
  else if(g_is_glut_initialized==false)
  {
    glutInit(&argc, fakeargv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    g_is_glut_initialized = true;
  }

  int id = getFreeSlot();

  if(id==-1)
  {
    cout << "Obvious2D:: Maximum number of instances reached" << endl;
    abort();
  }

  glutInitWindowSize(width, height);
  glutInitWindowPosition(0, 0);
  _handle = glutCreateWindow(title);

  _instanceID = id;
  g_instance_map[_instanceID] = true;

  pthread_mutex_init(&_mutex, NULL);

  _fullscreen = false;
  _screen_width = glutGet(GLUT_SCREEN_WIDTH);
  _screen_height = glutGet(GLUT_SCREEN_HEIGHT);
  _width  = width;
  _height = height;
  _init_width = _width;
  _init_height = _height;
  _mCallback['q'] = _onCloseEventSlot[_instanceID];
  _mCallback['f'] = _onToggleScreenSlot[_instanceID];

  g_this[_instanceID] = this;

  _setupGlutSlot[_instanceID]();
  glPixelZoom(1.0, -1.0);

  for(int i=0; i<TEXTMAX; i++)
    _text[i].text[0] = '\0';

  _textCnt = 0;
  _isAlive = true;
}

Obvious2D::~Obvious2D()
{
  if (glutGameModeGet(GLUT_GAME_MODE_ACTIVE)) glutLeaveGameMode();
  glutDestroyWindow(_handle);
  pthread_mutex_destroy(&_mutex);
  g_instance_map[_instanceID] = false;
  cout << "Destroy window" << endl;
}

unsigned int Obvious2D::getWidth()
{
  return _width;
}

unsigned int Obvious2D::getHeight()
{
  return _height;
}

void Obvious2D::setWidth(unsigned int width)
{
  _width = width;
}

void Obvious2D::setHeight(unsigned int height)
{
  _height = height;
}

unsigned int Obvious2D::getInitWidth() const
{
  return _init_width;
}

unsigned int Obvious2D::getInitHeight() const
{
  return _init_height;
}

unsigned int Obvious2D::getScreenWidth() const
{
  return _screen_width;
}

unsigned int Obvious2D::getScreenHeight() const
{
  return _screen_height;
}

bool Obvious2D::getFullscreen() const
{
  return _fullscreen;
}

void Obvious2D::setFullscreen(bool fullscreen)
{
  _fullscreen = fullscreen;
}

bool Obvious2D::isAlive() const
{
  return _isAlive;
}

void Obvious2D::terminate()
{
  _isAlive = false;
}

void Obvious2D::draw(unsigned char* image, unsigned int width, unsigned int height, unsigned int channels)
{
  if(!_isAlive) return;

  pthread_mutex_lock(&_mutex);
  glutSetWindow(_handle);

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  float ratioW = 1.001*(float)_width/width;
  float ratioH = 1.001*(float)_height/height;
  glPixelZoom(ratioW, -ratioH);

  if(channels==1)
    glDrawPixels(width, height, GL_LUMINANCE,GL_UNSIGNED_BYTE, image);
  else if(channels==3)
    glDrawPixels(width, height, GL_RGB,GL_UNSIGNED_BYTE, image);
  else
    cout << "WARNING: draw method not implemented for channels=" << channels << endl;

  for(int j=0; j<_textCnt; j++)
  {
    if(strlen(_text[j].text)>0)
    {
      glPushMatrix();
      // Flip vertically for correct text display
      glPixelZoom(ratioW, ratioH);
      glColor3f(0.0, 1.0, 0.0);
      glWindowPos2i(_text[j].col, _text[j].row);
      for (int i=0; i<strlen(_text[j].text); i++)
        glutBitmapCharacter(GLUT_BITMAP_9_BY_15, (int)_text[j].text[i]);
      glRasterPos2f(-1.0, 1.0);
      glPopMatrix();
    }
  }

  glutSwapBuffers();
  glutMainLoopEvent();

  pthread_mutex_unlock(&_mutex);
}

void Obvious2D::registerKeyboardCallback(char key, fptrKeyboardCallback callback)
{
  _mCallback[key] = callback;
}

void Obvious2D::addText(char* text, unsigned int c, unsigned int r)
{
  if(_textCnt >= TEXTMAX)
    return;
  unsigned int size = strlen(text);
  if(size>255) size = 255;
  memcpy(_text[_textCnt].text, text, size*sizeof(char));
  text[size] = '\0';
  _text[_textCnt].col = c;
  _text[_textCnt].row = r;
  _textCnt++;
}

void Obvious2D::clearText(void)
{
  _textCnt = 0;
}

void Obvious2D::processCallback(char key)
{
  fptrKeyboardCallback fptr = _mCallback[key];
    if(fptr!=NULL)(*fptr)();
}

}
