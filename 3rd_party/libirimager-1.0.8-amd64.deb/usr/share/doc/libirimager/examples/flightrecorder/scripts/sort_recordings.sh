#!/bin/sh
# allocate file in /tmp to verify execution
LOGFILE=/tmp/flightrecorder_`date +"%H-%M-%S"`.log
touch $LOGFILE
# directory configuration
DIR_SD=/media/odroid/sdcard
DIR_EMMC=/home/odroid/emmc
DIR_USB=/media/usbstick
mount ${DIR_USB}
# execution of file merging
for FILE in `ls -1 $DIR_SD/*.raw | tr '\n' '\0' | xargs -0 -n 1 basename`
do
	echo "copy" ${DIR_SD}/$FILE ${DIR_EMMC}/$FILE "to" ${DIR_USB}/$FILE >> $LOGFILE
	/home/odroid/examples/flightrecorder/build/sort_recordings ${DIR_SD}/${FILE} ${DIR_EMMC}/$FILE ${DIR_USB}/${FILE}
	echo "rm" ${DIR_SD}/$FILE ${DIR_EMMC}/$FILE >> $LOGFILE
	rm ${DIR_SD}/$FILE ${DIR_EMMC}/$FILE
done
sync
