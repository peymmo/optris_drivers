#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <limits.h>

using namespace std;

/**
 * Sorting IR data stored in two record files
 * @author Stefan May
 * @data 24.01.2015
 */
int main (int argc, char* argv[])
{
  if(argc!=4)
  {
    cout << "usage: " << argv[0] << " <file1> <file2> <outputfile>" << endl;
    return -1;
  }

  ifstream file1;
  ifstream file2;
  ofstream fileOut;

  file1.open(argv[1], ios::in | ios::binary);
  file2.open(argv[2], ios::in | ios::binary);
  fileOut.open(argv[3], ios::out | ios::binary);

  if(file1.is_open() && file2.is_open() && fileOut.is_open())
  {
    char sdate1[64];
    char stime1[64];
    unsigned long serial1;

    char sdate2[64];
    char stime2[64];
    unsigned long serial2;

    file1.read(sdate1, 8);
    sdate1[8] = '\0';
    file2.read(sdate2, 8);
    sdate2[8] = '\0';

    file1.read(stime1, 6);
    stime1[6] = '\0';
    file2.read(stime2, 6);
    stime2[6] = '\0';

    if(strncmp(sdate1, sdate2, 8) || strncmp(stime1, stime2, 6))
    {
      cout << "files were recorded at different points of time ... aborting()" << endl;
      abort();
    }

    file1.read((char*)&serial1, sizeof(serial1));
    file2.read((char*)&serial2, sizeof(serial2));

    if(serial1 != serial2)
    {
      cout << "files were recorded from different devices ... aborting()" << endl;
      abort();
    }

    // verify data size (buffers need to be equal)
    int w1;
    int h1;
    unsigned short bitCount1;
    int w2;
    int h2;
    unsigned short bitCount2;
    file1.read((char*)(&w1), sizeof(w1));
    file1.read((char*)(&h1), sizeof(h1));
    file1.read((char*)(&bitCount1), sizeof(bitCount1));

    file2.read((char*)(&w2), sizeof(w2));
    file2.read((char*)(&h2), sizeof(h2));
    file2.read((char*)(&bitCount2), sizeof(bitCount2));

    int size1 = w1*h1*bitCount1/8;
    int size2 = w2*h2*bitCount2/8;
    if(size1 != size2)
    {
      cout << "files with different buffer sizes passed ... aborting" << endl;
      abort();
    }

    long long avgTimePerFrame1;
    long long avgTimePerFrame2;
    file1.read((char*)(&avgTimePerFrame1), sizeof(avgTimePerFrame1));
    file2.read((char*)(&avgTimePerFrame2), sizeof(avgTimePerFrame2));
    if(avgTimePerFrame1 != avgTimePerFrame2)
    {
      cout << "files with different frame rates passed ... aborting" << endl;
      abort();
    }

    cout << "Recording of serial: " << serial1 << ", date: " << sdate1 << ", time: " << stime1 << endl;

    fileOut.write(sdate1, 8);
    fileOut.write(stime1, 6);
    fileOut.write((char*)&serial1, sizeof(serial1));
    fileOut.write((char*)&w1, sizeof(w1));
    fileOut.write((char*)&h1, sizeof(h1));
    fileOut.write((char*)&bitCount1, sizeof(bitCount1));
    fileOut.write((char*)&avgTimePerFrame1, sizeof(avgTimePerFrame1));

    char* buf = new char[size1];

    unsigned int id1;
    unsigned int id2;
    file1.read((char*)(&id1), sizeof(id1));
    file2.read((char*)(&id2), sizeof(id2));

    cout << "sorting data" << endl;
    while( !(file1.eof()) || !(file2.eof()) )
    {

      if(!(file1.eof()) && ((id1<id2) || file2.eof()))
      {
        cout << id1 << " ";
        file1.read(buf, size1*sizeof(*buf));
        fileOut.write(buf, size1*sizeof(*buf));
        file1.read((char*)(&id1), sizeof(id1));
      }
      else if(!(file2.eof()))
      {
        cout << id2 << " ";
        file2.read(buf, size2*sizeof(*buf));
        fileOut.write(buf, size1*sizeof(*buf));
        file2.read((char*)(&id2), sizeof(id2));
      }
    }

    cout << endl << "done" << endl;
    delete [] buf;
  }

  if(file1.is_open()) file1.close();
  if(file2.is_open()) file2.close();
  if(fileOut.is_open()) fileOut.close();

  return 1;
}
