#include <stdio.h>
#include <string.h>
#include <iostream>
#include <pthread.h>
#include <sys/time.h>
#include <fstream>
#include <sys/stat.h>

/**
 * Visualization
 */
#include "ImageBuilder.h"

using namespace std;
using namespace optris;

int main (int argc, char* argv[])
{
  if(argc<2)
  {
    cout << "usage: " << argv[0] << " <filename>" << endl;
    return 1;
  }

  char* fileIn = argv[1];

  // Determine image format
  struct stat filestatus;
  stat(fileIn, &filestatus);
  unsigned int w = 382;
  unsigned int h = 288;
  int bytes = filestatus.st_size;

  switch(bytes)
  {
  case 160*120*2:
    w = 160;
    h = 120;
    break;
  case 382*288*2:
    w = 382;
    h = 288;
    break;
  case 640*480*2:
    w = 640;
    h = 480;
    break;
  default:
    cout << "wrong file format with " << bytes << " Bytes" << endl;
    return 1;
  }

  // output file name = input filename with ending "ppm"
  int len = strlen(fileIn);
  char* fileOut = new char[len];
  memcpy(fileOut, fileIn, len);
  sprintf(&(fileOut[len-3]), "ppm");

  ifstream f;
  f.open(fileIn);

  unsigned short* buffer = new unsigned short[w*h];
  unsigned char* image = new unsigned char[w*h*3];

  f.read((char*)buffer, w*h*sizeof(*buffer));
  f.close();

  ImageBuilder iBuilder;
  iBuilder.setData(w, h, buffer);
  iBuilder.convertTemperatureToPaletteImage(image, true);
  iBuilder.serializePPM(fileOut, image, w, h);

  delete [] image;
  delete [] buffer;
  delete [] fileOut;
}

