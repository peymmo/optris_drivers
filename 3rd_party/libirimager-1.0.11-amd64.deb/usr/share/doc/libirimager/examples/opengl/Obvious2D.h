/*
 * This file is part of the Obviously library.
 *
 * Copyright(c) 2010-2012 Georg-Simon-Ohm University, Nuremberg.
 * http://www.ohm-university.eu
 *
 * This file may be licensed under the terms of of the
 * GNU General Public License Version 2 (the ``GPL'').
 *
 * Software distributed under the License is distributed
 * on an ``AS IS'' basis, WITHOUT WARRANTY OF ANY KIND, either
 * express or implied. See the GPL for the specific language
 * governing rights and limitations.
 *
 * You should have received a copy of the GPL along with this
 * program. If not, go to http://www.gnu.org/licenses/gpl.html
 * or write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */

#ifndef OBVIOUS2D_H
#define OBVIOUS2D_H

#include "Obvious.h"
#include <pthread.h>
#include <map>

namespace obvious
{

#define TEXTMAX 10
  struct TextStruct
  {
    char text[256];
    unsigned int col;
    unsigned int row;
  };

  /**
   * GLUT-based 2D viewer
   * @author Stefan May
   */
  class Obvious2D
  {
  public:
    /**
     * Standard Constructor
     * @param[in] width Image width, i.e., number of columns
     * @param[in] height Image height, i.e., number of rows
     * @param[in] title Window title
     */
    Obvious2D(unsigned int width, unsigned int height, const char* title);

    /**
     * Destructor
     */
    ~Obvious2D();

    /**
     * Initial width of window
     * @return width
     */
    unsigned int getWidth();

    /**
     * Set window width
     * @param width window width
     */
    void setWidth(unsigned int width);

    /**
     * Height of window
     * @return height
     */
    unsigned int getHeight();

    /**
     * Set window height
     * @param height window height
     */
    void setHeight(unsigned int height);

    /**
     * Get width at initialization time
     * @return init width
     */
    unsigned int getInitWidth() const;

    /**
     * Get height at initialization time
     * @return init height
     */
    unsigned int getInitHeight() const;

    /**
     * Get width of screen
     * @return screen width
     */
    unsigned int getScreenWidth() const;

    /**
     * Get height of screen
     * @return screen height
     */
    unsigned int getScreenHeight() const;

    /**
     * Get fullscreen flag
     */
    bool getFullscreen() const;

    /**
     * Set fullscreen flag
     * @param fullscreen fullscreen flag
     */
    void setFullscreen(bool fullscreen);

    /**
     * Flag indicating that viewer is still to be drawn
     */
    bool isAlive() const;

    /**
     * Terminate viewer
     */
    void terminate();

    /**
     * Draw image to screen
     * @param[in] image Pointer to image data (size = width*height*channels)
     * @param[in] width Image width
     * @param[in] height Image height
     * @param[in] channels Number of image channels
     */
    void draw(unsigned char* image, unsigned int width, unsigned int height, unsigned int channels);

    /**
     * Register keyboard events
     * @param callback pointer to callback function
     */
    void registerKeyboardCallback(char key, fptrKeyboardCallback callback);

    /**
     * Add a text to be displayed
     * @param[in] text Text buffer
     * @param[in] c Column of display position
     * @param[in] r Row of display position
     */
    void addText(char* text, unsigned int c, unsigned int r);

    /*
     * Clears the texts to be displayed
     */
    void clearText(void);

    /**
     * Process registered callback
     * @param key registered key
     */
    void processCallback(char key);

  private:

    // Text to be displayed
    TextStruct _text[TEXTMAX];
    unsigned int _textCnt;

    // GLUT window handle
    int _handle;

    // Mutex
    pthread_mutex_t _mutex;

    // Is alive flag
    bool _isAlive;

    // Width of GLUT window
    unsigned int _width;

    // Height of GLUT window
    unsigned int _height;

    // Initial width passed via constructor
    unsigned int _init_width;

    // Initial height passed via constructor
    unsigned int _init_height;

    // Width of screen
    unsigned int _screen_width;

    // Height of screen
    unsigned int _screen_height;

    // Fullscreen flag
    bool _fullscreen;

    // Instance ID
    unsigned int _instanceID;

    // Callback map
    std::map<char, fptrKeyboardCallback> _mCallback;

  };

}

#endif //OBVIOUS2D_H
