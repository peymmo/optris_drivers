#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <syslog.h>
#include <cstdlib>
#include <string.h>
#include <iostream>
#include "GpioAccess.h"

using namespace std;

bool _launch = false;
bool _run = true;
GPIOAccess* _gpio;

void signal_handler(int sig)
{
    switch(sig)
    {
        case SIGCONT:
            syslog(LOG_INFO, "System launch signal received");
            _launch = true;
            break;
        case SIGINT:
        case SIGTERM:
          syslog(LOG_INFO, "Termination signal received");
            //exit(EXIT_SUCCESS);
          _run = false;
            break;
        default:
          syslog(LOG_INFO, "Unhandled signal received");
            break;
    }
}

bool gpio_handler()
{
  string inputstate;
  _gpio->getvalGPIO(inputstate);
  bool gpioSignal = (inputstate == "1");
  static bool gpioSignalPrev = gpioSignal;

  // launch application at raising edge
  if(gpioSignal && !gpioSignalPrev)
  {
    syslog(LOG_INFO, "GPIO launch signal received");
    _launch = true;
  }
  gpioSignalPrev = gpioSignal;
}

int main(int argc, char* argv[])
{
  if (argc != 3)
  {
    syslog(LOG_ERR, "Wrong number of arguments passed");
    exit(EXIT_FAILURE);
  }

  struct stat sb;

  if (stat(argv[1], &sb) == -1)
  {
    syslog(LOG_ERR, "Imager configuration file does not exist");
    exit(EXIT_FAILURE);
  }

  if (stat(argv[2], &sb) == -1)
  {
    syslog(LOG_ERR, "Record configuration file does not exist");
    exit(EXIT_FAILURE);
  }

  int pid_file = open("/tmp/flight_recorder_service.pid", O_CREAT | O_RDWR, 0666);
  int rc = flock(pid_file, LOCK_EX | LOCK_NB);
  if(rc)
  {
      if(EWOULDBLOCK == errno)
          exit(1);
  }

  // Change file mode mask
  umask(0);

  // Open service log file
  openlog("flight_recorder_service.log", LOG_PID|LOG_CONS, LOG_USER);

  // Signal handling
  struct sigaction newSigAction;
  sigset_t newSigSet;

  // Set signal mask - signals we want to block
  sigemptyset(&newSigSet);
  sigaddset(&newSigSet, SIGCHLD);  // ignore child - i.e. we don't need to wait for it
  sigaddset(&newSigSet, SIGTSTP);  // ignore Tty stop signals
  sigaddset(&newSigSet, SIGTTOU);  // ignore Tty background writes
  sigaddset(&newSigSet, SIGTTIN);  // ignore Tty background reads
  sigprocmask(SIG_BLOCK, &newSigSet, NULL);   // Block the above specified signals

  // Set up a signal handler
  newSigAction.sa_handler = signal_handler;
  sigemptyset(&newSigAction.sa_mask);
  newSigAction.sa_flags = 0;

  // Signals to handle
  sigaction(SIGCONT, &newSigAction, NULL);     // catch hangup signal
  sigaction(SIGTERM, &newSigAction, NULL);     // catch term signal
  sigaction(SIGINT,  &newSigAction, NULL);     // catch interrupt signal

  _gpio = new GPIOAccess();
  _gpio->exportGPIO();
  _gpio->setdirGPIO("in");

  while(_run)
  {
    gpio_handler();
    if(_launch)
    {
      char cmd[512];
      snprintf(cmd, 512, "flight_recorder %s %s", argv[1], argv[2]);
      system(cmd);
      _launch = false;
    }
    usleep(5000);
  }

  _gpio->unexportGPIO();
  delete _gpio;

  close(pid_file);
  flock(pid_file, LOCK_UN);
}
