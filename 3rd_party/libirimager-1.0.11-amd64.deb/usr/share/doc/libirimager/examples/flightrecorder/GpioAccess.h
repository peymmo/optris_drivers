/**
 * Taken (and modified) from Raspberry Pi Blog entry: Introduction to accessing the Raspberry Pi’s GPIO in C++ (sysfs) / Hertaville
 */

#ifndef GPIO_ACCESS_H
#define GPIO_ACCESS_H

#include <string>
using namespace std;

/**
 * @class GPIO access interface
 * Purpose: Each object instantiated from this class will control a GPIO pin
 * The GPIO pin number must be passed to the overloaded class constructor
 */
class GPIOAccess
{
public:
  /**
   * Create a GPIO object related to port 200 (default)
   */
  GPIOAccess();

  /**
   * Create a GPIO object that controls GPIOx
   * @param x gpio port
   */
  GPIOAccess(string x);

  /**
   * Export GPIO pin
   * @return success==0, else -1
   */
  int exportGPIO();

  /**
   * Unexport GPIO pin
   * @return success==0, else -1
   */
  int unexportGPIO();

  /**
   * Set GPIO direction
   * @param dir "in" or "out"
   * @return success==0, else -1
   */
  int setdirGPIO(string dir);

  /**
   * Set GPIO value (if "out" is specified)
   * @param val value "0" or "1"
   * @return success==0, else -1
   */
  int setvalGPIO(string val);

  /**
   * Read GPIO value (if "in" is specified)
   * @param val value "0" or "1" will be returned
   * @return success==0, else -1
   */
  int getvalGPIO(string& val);

  /**
   * return the GPIO number associated with the instance of an object
   */
  string getNumGPIO();

private:

  /**
   * GPIO number associated with the instance of an object
   */
  string gpionum;
};

#endif
