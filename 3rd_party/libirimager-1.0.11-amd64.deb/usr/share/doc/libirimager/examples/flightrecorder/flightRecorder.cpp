#include <stdio.h>
#include <string.h>
#include <iostream>
#include <pthread.h>
#include <sys/time.h>
#include <sys/file.h>
#include <unistd.h>
#include <vector>
#include <list>
#include <sys/stat.h>
#include <errno.h>
#include <signal.h>
#include <syslog.h>

// Optris interface
#include "IRImager.h"
#include "ImageBuilder.h"
#include "SimpleXML.h"

// Visualization
#include "../opengl/Obvious2D.h"
#include <GL/freeglut.h>

// File Utilities
#include "FileWriter.h"

using namespace std;
using namespace optris;

unsigned int _buf_size = 0;
unsigned long _serial = 0;
unsigned int _image_id = 0;
unsigned int _cnt_queued = 0;

#define ASSIGN_UNKNOWN  -1
#define ASSIGN_SD        0
#define ASSIGN_EMMC      1
#define ASSIGN_DROP      2
std::vector<int> _assignments;

#define MAX_QUEUE_LENGTH 250

IRImager* _imager;
time_t _timeStart;

struct thread_context
{
  pthread_mutex_t mutex;
  pthread_cond_t available;
};

struct serialization_context
{
  thread_context ctx_th;
  char* basedir;
  int assignment_id;
  std::list<unsigned char*> images;
  std::list<unsigned int> assignments;
  unsigned int cnt_serialized;
  unsigned int cnt_dropped;
  std::vector<unsigned int> queue_length;
};

serialization_context _context_sd = {{PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER},
                                      NULL,
                                      ASSIGN_SD};

serialization_context _context_emmc = {{PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER},
                                        NULL,
                                        ASSIGN_EMMC};

unsigned short* _image_thermal = NULL;

// Threaded functions for parallelizing work
void* processingWorker(void* arg);
std::list<unsigned char*> _buffer_raw;
std::vector<unsigned int> _queue_length_raw;

void* serializationWorker(void* arg);

bool _run = 1;
bool _record = 0;

void wakeUpThread(thread_context* context)
{
  pthread_mutex_lock(&(context->mutex));
  pthread_cond_signal(&(context->available));
  pthread_mutex_unlock(&(context->mutex));
}

// Callback function indicating availability of thermal data
void onThermalFrame(unsigned short* image, unsigned int w, unsigned int h, long long timestamp, void* arg)
{
  if(_image_thermal == NULL)
    _image_thermal = new unsigned short[w * h];
  memcpy(_image_thermal, image, w * h * sizeof(*image));
}

// Queue manager for serialization pipeline
void queueDataForSerialization(unsigned char* image, unsigned int buf_size, thread_context* context_sd, thread_context* context_emmc);

// Main recording loop
int startRecording();

int main(int argc, char* argv[])
{
  int pid_file = open("/tmp/flight_recorder.pid", O_CREAT | O_RDWR, 0666);
  int rc = flock(pid_file, LOCK_EX | LOCK_NB);
  if(rc)
  {
      if(EWOULDBLOCK == errno)
          exit(1);
  }

  if(argc != 3)
  {
    cout << "usage: " << argv[0] << " <cam xml> <app xml>" << endl;
    cout << " <cam xml>: camera xml configuration file" << endl;
    cout << " <app xml>: application xml configuration file" << endl;
    return -1;
  }

  _timeStart = time(NULL);

  //--------------------- Read path configuration for serialization ---------------------
  SimpleXML xml;
  if(xml.Open(argv[2], "flightrecorder"))
  {
    xml.SetNode();
    xml.GetString("dir1", &(_context_sd.basedir));
    xml.GetString("dir2", &(_context_emmc.basedir));
    int retval = mkdir(_context_sd.basedir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    if(retval != 0 && errno != EEXIST)
    {
      cout << "Directory " << _context_sd.basedir << " cannot be created, nor it exists." << endl;
      return -1;
    }
    errno = 0;
    retval = mkdir(_context_emmc.basedir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    if(retval != 0 && errno != EEXIST)
    {
      cout << "Directory " << _context_emmc.basedir << " cannot be created, nor it exists." << endl;
      return -1;
    }
    cout << "Serializing to " << _context_sd.basedir << " and " << _context_emmc.basedir << endl;
  }
  //-------------------------------------------------------------------------------------

  //--------------------- Initialize Optris image processing chain ----------------------

  _imager = new IRImager(argv[1]);
  if(_imager->getWidth() == 0 || _imager->getHeight() == 0)
  {
    cout << "Error: Image streams not available or wrongly configured. Check connection of camera and config file." << endl;
    return -1;
  }

  _serial = _imager->getSerial();

  cout << "Thermal channel: " << _imager->getWidth() << "x" << _imager->getHeight() << "@" << _imager->getMaxFramerate() << "Hz" << endl;

  _imager->startStreaming();

  int retval = 0;

  _record = 1;
  startRecording();

  _imager->stopStreaming();
  delete _imager;

  cout << "Exit application" << endl  ;

  raise(SIGTERM);

  return 1;
}

int startRecording()
{
  unsigned int bufferSize = _imager->getRawBufferSize();
  unsigned char* bufferRaw = new unsigned char[bufferSize];
  _imager->setFrameCallback(onThermalFrame);

  //-------------------------------------------------------------------------------------
  pthread_t th_display;
  pthread_t th_process;
  pthread_t th_sdcard;
  pthread_t th_emmc;

  thread_context context_process = {PTHREAD_MUTEX_INITIALIZER, PTHREAD_COND_INITIALIZER};

  pthread_create(&th_process, NULL, processingWorker, &context_process);
  pthread_create(&th_sdcard, NULL, serializationWorker, &_context_sd);
  pthread_create(&th_emmc, NULL, serializationWorker, &_context_emmc);

  while(_record)
  {
    if(_imager->getFrame(bufferRaw))
    {
      unsigned char* buf = new unsigned char[bufferSize];
      memcpy(buf, bufferRaw, bufferSize);
      _imager->releaseFrame();

      // put data in serialization queue
      queueDataForSerialization(buf, bufferSize, &(_context_sd.ctx_th), &(_context_emmc.ctx_th));

      // put data in processing queue
      pthread_mutex_lock(&(context_process.mutex));
      _buffer_raw.push_back(buf);
      pthread_cond_signal(&(context_process.available));
      pthread_mutex_unlock(&(context_process.mutex));

      usleep(1000);
    }
  }

  cout << "leaving record loop" << endl;
  delete[] bufferRaw;

  _record = 0;

  // wait for finalizing the serialization tasks
  wakeUpThread(&context_process);
  wakeUpThread(&(_context_sd.ctx_th));
  wakeUpThread(&(_context_emmc.ctx_th));

  // wait for finalizing the serialization threads
  int retval;
  pthread_join(th_process, (void**)&retval);
  pthread_join(th_sdcard, (void**)&retval);
  pthread_join(th_emmc, (void**)&retval);

  cout << "# Serialized " << _context_sd.cnt_serialized + _context_emmc.cnt_serialized << " images, dropped " << _context_sd.cnt_dropped + _context_emmc.cnt_dropped << " images" << endl;

  return 0;
}

void* processingWorker(void* arg)
{
  int w = _imager->getWidth();
  int h = _imager->getHeight();

  thread_context* context = (thread_context*)arg;
  obvious::Obvious2D viewer(w, h, "Flightrecorder");

  ImageBuilder iBuilder;
  iBuilder.setPaletteScalingMethod(eMinMax);
  iBuilder.setManualTemperatureRange(15.0f, 40.0f);

  unsigned char* bufferPalette = NULL;

  while((_record | !_buffer_raw.empty()) && viewer.isAlive())
  {
    // wait for new data
    pthread_mutex_lock(&(context->mutex));
    if(_buffer_raw.empty())
      pthread_cond_wait(&(context->available), &(context->mutex));
    pthread_mutex_unlock(&(context->mutex));

    // trigger libimager
    unsigned char* buf = _buffer_raw.back();
    _imager->process(buf);
    delete[] buf;

    iBuilder.setData(w, h, _image_thermal);
    if(bufferPalette == NULL)
      bufferPalette = new unsigned char[iBuilder.getStride() * h * 3];

    iBuilder.convertTemperatureToPaletteImage(bufferPalette);
    pthread_mutex_unlock(&(context->mutex));

    viewer.draw(bufferPalette, iBuilder.getStride(), h, 3);

    // pop first element in queue
    pthread_mutex_lock(&(context->mutex));
    _buffer_raw.clear();
    pthread_mutex_unlock(&(context->mutex));
  }
  _record = 0;

  if(bufferPalette)
  {
    delete[] bufferPalette;
    bufferPalette = NULL;
  }

  cout << "exit processing worker" << endl;

  pthread_exit((void**)1);

  return NULL;
}

void* serializationWorker(void* arg)
{
  serialization_context* ctx_ser = (serialization_context*)arg;
  thread_context* context = &(ctx_ser->ctx_th);

  FileWriter* f = NULL;

  while(_record | !ctx_ser->images.empty())
  {
    pthread_mutex_lock(&(context->mutex));
    if(ctx_ser->images.empty())
      pthread_cond_wait(&(context->available), &(context->mutex));
    pthread_mutex_unlock(&(context->mutex));

    if(!ctx_ser->images.empty())
    {
      // Write data
      unsigned char* img = ctx_ser->images.front();
      unsigned int id = ctx_ser->assignments.front();
      if(ctx_ser->images.size() < MAX_QUEUE_LENGTH)
      {
        if(f == NULL)
          f = new FileWriter(ctx_ser->basedir, _imager, _timeStart);
        f->write(id, img, _buf_size);
        ctx_ser->cnt_serialized++;
        _assignments[id] = ctx_ser->assignment_id;
      }
      else
      {
        cout << "# Warning: Serialization to " << ctx_ser->basedir << " too slow ... dropping frame" << endl;
        _assignments[id] = ASSIGN_DROP;
        ctx_ser->cnt_dropped++;
      }
      delete[] img;

      // pop first element in queue
      pthread_mutex_lock(&(context->mutex));
      ctx_ser->images.pop_front();
      ctx_ser->assignments.pop_front();
      pthread_mutex_unlock(&(context->mutex));
    }
  }

  delete f;
  f = NULL;

  cout << "exit serialization worker" << endl;

  pthread_exit((void**)1);

  return NULL;
}

void queueDataForSerialization(unsigned char* image, unsigned int buf_size, thread_context* context_sd, thread_context* context_emmc)
{
  // make local copy of data
  _buf_size = buf_size;
  unsigned char* img = new unsigned char[buf_size];
  memcpy(img, image, buf_size * sizeof(*image));
  _assignments.push_back(ASSIGN_UNKNOWN);

  // measure current queue length
  _context_sd.queue_length.push_back(_context_sd.images.size());
  _context_emmc.queue_length.push_back(_context_emmc.images.size());
  _queue_length_raw.push_back(_buffer_raw.size());

  // balance serialization queues
  static int cnt = 0;
  bool serializeToEMMC = _context_sd.images.size() > _context_emmc.images.size();
  if(_context_sd.images.size() == _context_emmc.images.size()) serializeToEMMC = ((cnt++)%2);
  if(serializeToEMMC)
  {
    pthread_mutex_lock(&(context_emmc->mutex));
    _context_emmc.images.push_back(img);
    _context_emmc.assignments.push_back(_image_id++);
    pthread_cond_signal(&(context_emmc->available));
    pthread_mutex_unlock(&(context_emmc->mutex));
  }
  else
  {
    pthread_mutex_lock(&(context_sd->mutex));
    _context_sd.images.push_back(img);
    _context_sd.assignments.push_back(_image_id++);
    pthread_cond_signal(&(context_sd->available));
    pthread_mutex_unlock(&(context_sd->mutex));
  }
  _cnt_queued++;
}
